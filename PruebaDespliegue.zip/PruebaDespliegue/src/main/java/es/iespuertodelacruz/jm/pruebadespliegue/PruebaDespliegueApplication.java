package es.iespuertodelacruz.jm.pruebadespliegue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaDespliegueApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaDespliegueApplication.class, args);
	}

}
